//
//  GameViewController.swift
//  Hangman
//
//  Created by Shawn D'Souza on 3/3/16.
//  Copyright © 2016 Shawn D'Souza. All rights reserved.
//

import UIKit

class HangmanViewController: UIViewController/*,UITextFieldDelegate*/ {
    
    var thePhrase = String()
    var blanksLayout = String()
    var attemptedLetters = String()
    var correctGuesses = String()
    var incorrectGuesses2 = String()
    var blankSpaceTemp = String()
    var badGuessCount = Int()
    var liveGame = Bool()
    
    override func viewDidLoad() {
        //guessTextField.becomeFirstResponder()
        liveGame = true
        baneSpeech.text = "Can you beat me in a battle of wits?"
        super.viewDidLoad()
        let hangmanPhrases = HangmanPhrases()
        // Generate a random phrase for the user to guess
        let phrase: String = hangmanPhrases.getRandomPhrase()
        thePhrase = phrase
        blankCreater()
        banePanel.image = #imageLiteral(resourceName: "Image")
        nooseMan.image = #imageLiteral(resourceName: "hangman1")
        print(phrase)
    }
   // var newStr:String = str + String(aCharacter)
    
    func blankCreater() {
        IncorrectGuesses.text = ""
        incorrectGuesses2 = ""
        correctGuesses = ""
        attemptedLetters = ""
        blanksLayout = ""
        badGuessCount = 0;
        for character in thePhrase.characters{
            if String(character) == " " {
                blanksLayout = blanksLayout + "      "
            } else {
             blanksLayout = blanksLayout + "_  "
            }
            //print(character)
            
        }
        Blanks.text = blanksLayout
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        //
        print("incredible, u wanna type")
        return true
       // 
    }
    
    @IBOutlet weak var Blanks: UILabel!
    @IBOutlet weak var nooseMan: UIImageView!

    @IBOutlet weak var banePanel: UIImageView!
    @IBOutlet weak var IncorrectGuesses: UILabel!
    @IBOutlet weak var guessTextField: UITextField!
    
    @IBOutlet weak var baneSpeech: UILabel!
    
    @IBAction func textFieldPressed(_ sender: Any) {
        guessTextField.becomeFirstResponder()
    }
    
   @IBAction func userTypes(_ sender: Any) {
        guessTextField.becomeFirstResponder()
    }
    var charCount = Int()
    func alpha (guessedLetter: String)->Bool{
        charCount = 0
        if ((guessedLetter.characters.count) < 2) && ((guessedLetter.characters.count) > 0) {
            for character in "ABCDEFGHIJKLMNOPQRSTUVWXYZ".characters{
                if character == Character(guessedLetter) {
                    charCount = charCount + 1
                }
        //return true
            }
            if charCount > 0 {
                return true
            } else {
                baneSpeech.text = "Enter a letter! Have you forgotten your ABC's?"
                
                return false
            }
            
        } else {
            baneSpeech.text = "One letter! No more, no less"
            
        }
        return false
    }
   /* @IBAction func restartedGame(_ sender: Any) {
    
        liveGame = true
        baneSpeech.text = "'So you've come back to die for your city'"
        //super.viewDidLoad()
        //let hangmanPhrases = HangmanPhrases()
        // Generate a random phrase for the user to guess
       // let phrase: String = hangmanPhrases.getRandomPhrase()
       // thePhrase = phrase
        //blankCreater()
        banePanel.image = #imageLiteral(resourceName: "Image")
        nooseMan.image = #imageLiteral(resourceName: "hangman1")
        //print(phrase)
        IncorrectGuesses.text = ""
    }*/
    
    @IBOutlet weak var restartHang: UIButton!
   
    @IBAction func restarted(_ sender: Any) {
        liveGame = true
        baneSpeech.text = "'So you've come back to die for your city'"
        super.viewDidLoad()
        let hangmanPhrases = HangmanPhrases()
        // Generate a random phrase for the user to guess
         let phrase: String = hangmanPhrases.getRandomPhrase()
         thePhrase = phrase
        blankCreater()
        banePanel.image = #imageLiteral(resourceName: "Image")
        nooseMan.image = #imageLiteral(resourceName: "hangman1")
        //print(phrase)
        IncorrectGuesses.text = ""
    }
    func endGame() {
        liveGame = false
    }
   // @IBAction func resetGame(_ sender: Any) {
    //}
    
    @IBAction func GuessButtonPressed(_ sender: Any) {
        //guessTextField.becomeFirstResponder()
        if liveGame{
        if alpha(guessedLetter: guessTextField.text!.uppercased()){
        validate(guessedLetter: guessTextField.text!.uppercased())
        }
        }
       // guessTextField.resignFirstResponder()
        print(guessTextField.text!)
        //guessTextField.becomeFirstResponder()
        
        //guessTextField.resignFirstResponder()
        //Blanks.text = guessTextField.text
        
    }
    
    func addToAG(attempt: Character) {
        attemptedLetters = attemptedLetters + String(attempt)
    }
    /*
     if badGuessCount == 0 {
     incorrectGuesses2 = incorrectGuesses2 + String(attempt)
     IncorrectGuesses.text = incorrectGuesses2
     badGuessCount = badGuessCount + 1
     }
 
    */
    func addToIG(attempt: Character) {
        switch badGuessCount{
        case 0:
            baneSpeech.text = "Incorrect. 'You fight like a younger person' - DKR"
            
            incorrectGuesses2 = incorrectGuesses2 + String(attempt)
            IncorrectGuesses.text = "Incorrect Guesses: "+incorrectGuesses2
            badGuessCount = badGuessCount + 1
            nooseMan.image = #imageLiteral(resourceName: "hangman2")
            
        case 1:
            baneSpeech.text = "Ungrateful for your second chance, are you now?"
            
            incorrectGuesses2 = incorrectGuesses2 + String(attempt)
            IncorrectGuesses.text = "Incorrect Guesses: "+incorrectGuesses2
            badGuessCount = badGuessCount + 1
            nooseMan.image = #imageLiteral(resourceName: "hangman3")
            
            
        case 2:
            baneSpeech.text = "'Admirable [attempt] but mistaken' - DKR"
            
            incorrectGuesses2 = incorrectGuesses2 + String(attempt)
            IncorrectGuesses.text = "Incorrect Guesses: "+incorrectGuesses2
            badGuessCount = badGuessCount + 1
            nooseMan.image = #imageLiteral(resourceName: "hangman4")
            
            
        case 3:
            baneSpeech.text = "'Peace has cost you your strength!' - DKR"
            
            incorrectGuesses2 = incorrectGuesses2 + String(attempt)
            IncorrectGuesses.text = "Incorrect Guesses: "+incorrectGuesses2
            badGuessCount = badGuessCount + 1
            nooseMan.image = #imageLiteral(resourceName: "hangman5")
            
            
        case 4:
            baneSpeech.text = "One more mistake and you're finished"
            incorrectGuesses2 = incorrectGuesses2 + String(attempt)
            IncorrectGuesses.text = "Incorrect Guesses: "+incorrectGuesses2
            badGuessCount = badGuessCount + 1
            nooseMan.image = #imageLiteral(resourceName: "hangman6")
            
            
        case 5:
            endGame()
            baneSpeech.text = "'The shadows betray you because they belong to me!'"
            incorrectGuesses2 = incorrectGuesses2 + String(attempt)
            IncorrectGuesses.text = "Incorrect Guesses: "+incorrectGuesses2
            badGuessCount = badGuessCount + 1
            nooseMan.image = #imageLiteral(resourceName: "hangman7")
            let alertController = UIAlertController(title: "You Lost!", message:
                "You can guess at most 6 wrong letters", preferredStyle: UIAlertControllerStyle.alert)
            alertController.addAction(UIAlertAction(title: "Accept Defeat", style: UIAlertActionStyle.default,handler: nil))
            
            self.present(alertController, animated: true, completion: nil)
            
            IncorrectGuesses.text = "GAME OVER"
        //case 6:
            
        default:
            IncorrectGuesses.text = "so you've come back to die for your city - BANE"
        }
    }
    
    func validate(guessedLetter: String) {
        
        if ((guessedLetter.characters.count) < 2) && ((guessedLetter.characters.count) > 0) {
                
            if unguessedBefore(letter: guessedLetter) {
                
                
                      print ("exclee")
                    surveyLoop: for character in thePhrase.characters{
                            if notWrong(letter: guessedLetter){
                                
                            
                                if character == Character(guessedLetter) {
                                    print(String(character)+" is IN")
                                    insertLetter(letter: character)
                                    addToAG(attempt: character)
                                    break surveyLoop
                                }
                                    //BREAK
                            } else {
                                //WRONG GUESS
                                addToAG(attempt: Character(guessedLetter))
                                addToIG(attempt: Character(guessedLetter))
                                break surveyLoop
                                
                                
                        }
                
                        //else {
                        //yet to cover space
                        //addToIG(attempt: character)
                        //addToAG(attempt: character)
                        // }
                        //print(character)
                    }
                
                
                
            }
        }
    }
    var counter3 = Int()
    func notWrong(letter: String)-> Bool {
        counter = 0
        for character in thePhrase.characters{
            if character == Character(letter) {
                counter = counter + 1
            }
            //print(character)
        }
        if (counter>0){
            return true
        } else {
            return false
        }
    }
    
    var counter = Int()
    func unguessedBefore(letter: String)-> Bool {
        counter = 0
        for character in attemptedLetters.characters{
            if character == Character(letter) {
                counter = counter + 1
            }
            //print(character)
        }
        if (counter>0){
            print("PREVIOUSLY TRIED")
            return false
            
        } else {
        return true
        }
    }
    
    var counter2 = Int()
    func charWasAlreadyInserted(letterCWAI: Character)->Bool{
        counter2 = 0
        for character in correctGuesses.characters{
            if character == letterCWAI {
                counter2 = counter2 + 1
            }
            //print(character)
        }
        if (counter2>0){
            //baneSpeech.text = "You already tried that!"
            return true
        } else {
            return false
        }

    }
    
    var i = Int()
    var _counter = Int()
    var testString = String()
    func didWin() {
        _counter = 0
        testString = Blanks.text!
        for character in (testString.characters){
            if String(character) == "_" {
                _counter = _counter + 1
            }
            
        }
        if _counter == 0 {
            endGame()
            baneSpeech.text = "'I broke you. How have you come back?'"
            let alertController = UIAlertController(title: "You Won!", message:
                "Bane has been defeated", preferredStyle: UIAlertControllerStyle.alert)
            alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.default,handler: nil))
            
            self.present(alertController, animated: true, completion: nil)
        }
    }
    
    func insertLetter(letter: Character) {
        i = 0
        blanksLayout = ""
        for character in thePhrase.characters{
            //i = i + 1
            if String(character) == String(letter) {
                //INSERT LETTER OR...
                correctGuesses = correctGuesses + String(letter)
                
                
                
                blanksLayout = blanksLayout + String(letter) + "  "
            } else if(String(character) == " "){
                //INSERT SPACE OR...
                blanksLayout = blanksLayout + "      "
                //spaceOrBlank
            } else if charWasAlreadyInserted(letterCWAI: character){
                //INSERT BLANK
                blanksLayout = blanksLayout + String(character) + "  "
                
                
            } else {
                //INSERT BLANK
                blanksLayout = blanksLayout + "_  "
            }
            //print(character)
            
        }
        Blanks.text = blanksLayout
        baneSpeech.text = "Nice attack"
        didWin()
    }
    
    
    func spaceOrBlank()->Bool{
        return true
    }
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
